function rotateword(str, rot)
	cstr = ""
	for c in str
		if isletter(c)
			a = islowercase(c) ? Int('a') : Int('A')
			c = Char(mod(Int(c) + rot - a, 26) + a)
		end
		cstr *= c
	end
	return cstr
end

rotateword(
"""

N PBQR BS RGUVPNY ORUNIVBE SBE CNGVRAGF: 

1. QB ABG RKCRPG LBHE QBPGBE GB FUNER LBHE QVFPBZSBEG. 
   Vaibyirzrag jvgu gur cngvrag'f fhssrevat zvtug pnhfr uvz gb ybfr inyhnoyr fpvragvsvp bowrpgvivgl. 
2. OR PURRESHY NG NYY GVZRF. 
   Lbhe qbpgbe yrnqf n ohfl naq gelvat yvsr naq erdhverf nyy gur tragyrarff naq ernffhenapr ur pna trg. 
3. GEL GB FHSSRE SEBZ GUR QVFRNFR SBE JUVPU LBH NER ORVAT GERNGRQ. 
   Erzrzore gung lbhe qbpgbe unf n cebsrffvbany erchgngvba gb hcubyq.
"""
, 13)