pos1 = scite.SendEditor(SCI_GETSELECTIONSTART)
pos2 = scite.SendEditor(SCI_GETSELECTIONEND)

editor:BeginUndoAction()

if pos1 == pos2 then
	pos2 = editor:PositionAfter(pos1)
	editor:SetSel(pos1, pos2) 
elseif pos1 > pos2 then
	tmp = pos1
	pos1 = pos2
	pos2 = tmp
end


sel = editor:GetSelText()



newpos = editor:PositionAfter(pos2)
editor:InsertText(newpos, sel)
editor:DeleteRange(pos1, pos2 - pos1)
editor:SetSel(pos1 + newpos - pos2, newpos)

editor:EndUndoAction()



