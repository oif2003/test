selstartpos = scite.SendEditor(SCI_GETSELECTIONSTART)
selendpos = scite.SendEditor(SCI_GETSELECTIONEND)
--Case: No selection made (Get current line)
if selstartpos == selendpos then
	text = editor:GetCurLine()
	text = string.gsub(text, "^%s+", "")	--removes leading blank
	text = string.gsub(text, "\n", "")
	text = string.gsub(text, "\r", "")
--Case: Selection
else
	text = editor:GetSelText()
end

--editor:CopyText(text)  --Send results to Clipboard

--Write to file instead


-- Opens a file in append mode
file = io.open("__temp.jl", "w")

-- sets the default output file as test.lua
io.output(file)

-- appends a word test to the last line of the file
io.write(text)

-- closes the open file
io.close(file)
