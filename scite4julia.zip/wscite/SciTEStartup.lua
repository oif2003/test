--output.ReadOnly = true

function test()
  return "msgbox"
end